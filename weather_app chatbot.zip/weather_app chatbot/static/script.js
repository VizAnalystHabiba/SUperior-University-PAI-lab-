// document.addEventListener('DOMContentLoaded', function() {
//     const chatBox = document.getElementById('chat-box');
//     const userInput = document.getElementById('user-input');
//     const sendButton = document.getElementById('send-button');
    
//     // Auto-focus input on load
//     userInput.focus();
    
//     // Send message functions
//     function sendMessage() {
//         const message = userInput.value.trim();
//         if (message === '') return;
        
//         // Add user message to chat
//         addMessage(message, 'user');
//         userInput.value = '';
        
//         // Show typing indicator
//         showTypingIndicator();
        
//         // Send to server and get response
//         fetch('/chat', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/x-www-form-urlencoded',
//             },
//             body: `message=${encodeURIComponent(message)}`
//         })
//         .then(response => response.json())
//         .then(data => {
//             removeTypingIndicator();
//             handleBotResponse(data);
//         })
//         .catch(error => {
//             removeTypingIndicator();
//             addMessage("Sorry, I'm having connection issues. Please try again.", 'bot');
//             console.error('Error:', error);
//         });
//     }
    
//     // Add message to chat
//     function addMessage(text, sender) {
//         const messageDiv = document.createElement('div');
//         messageDiv.classList.add(`${sender}-message`);
        
//         const messageContent = document.createElement('div');
//         messageContent.classList.add('message-content');
        
//         // Check if the text contains HTML tags
//         if (/<[a-z][\s\S]*>/i.test(text)) {
//             messageContent.innerHTML = text;
//         } else {
//             const p = document.createElement('p');
//             p.textContent = text;
//             messageContent.appendChild(p);
//         }
        
//         const messageTime = document.createElement('div');
//         messageTime.classList.add('message-time');
//         messageTime.textContent = getCurrentTime();
        
//         messageDiv.appendChild(messageContent);
//         messageDiv.appendChild(messageTime);
//         chatBox.appendChild(messageDiv);
        
//         // Scroll to bottom
//         chatBox.scrollTop = chatBox.scrollHeight;
//     }
    
//     // Handle bot response
//     function handleBotResponse(response) {
//         if (response.type === 'weather') {
//             // Update body class based on weather condition
//             if (response.weather_class) {
//                 document.body.className = response.weather_class;
//             }
//         }
//         addMessage(response.content, 'bot');
//     }
    
//     // Typing indicator functions
//     function showTypingIndicator() {
//         const typingDiv = document.createElement('div');
//         typingDiv.classList.add('typing-indicator');
//         typingDiv.id = 'typing-indicator';
        
//         for (let i = 0; i < 3; i++) {
//             const dot = document.createElement('span');
//             dot.classList.add('typing-dot');
//             typingDiv.appendChild(dot);
//         }
        
//         chatBox.appendChild(typingDiv);
//         chatBox.scrollTop = chatBox.scrollHeight;
//     }
    
//     function removeTypingIndicator() {
//         const typingIndicator = document.getElementById('typing-indicator');
//         if (typingIndicator) {
//             typingIndicator.remove();
//         }
//     }
    
//     // Get current time in HH:MM format
//     function getCurrentTime() {
//         const now = new Date();
//         return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
//     }
    
//     // Event listeners
//     sendButton.addEventListener('click', sendMessage);
//     userInput.addEventListener('keypress', function(e) {
//         if (e.key === 'Enter') {
//             sendMessage();
//         }
//     });
    
//     // Sample questions for quick input (optional)
//     const sampleQuestions = [
//         "What's the weather in London?",
//         "How's the weather in Tokyo?",
//         "Temperature in New York",
//         "Weather forecast for Paris",
//         "Show me a graph for Berlin"
//     ];
    
//     // Uncomment to add sample questions to the interface
//     /*
//     function addSampleQuestions() {
//         const samplesDiv = document.createElement('div');
//         samplesDiv.classList.add('sample-questions');
        
//         sampleQuestions.forEach(question => {
//             const btn = document.createElement('button');
//             btn.textContent = question;
//             btn.classList.add('sample-question');
//             btn.addEventListener('click', () => {
//                 userInput.value = question;
//                 userInput.focus();
//             });
//             samplesDiv.appendChild(btn);
//         });
        
//         chatBox.appendChild(samplesDiv);
//         chatBox.scrollTop = chatBox.scrollHeight;
//     }
    
//     addSampleQuestions();
//     */
// });


document.addEventListener('DOMContentLoaded', function() {
    const chatBox = document.getElementById('chat-box');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    
    // Auto-focus input on load
    userInput.focus();
    
    function sendMessage() {
        const message = userInput.value.trim();
        if (message === '') return;
        
        addMessage(message, 'user');
        userInput.value = '';
        
        showTypingIndicator();
        
        fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `message=${encodeURIComponent(message)}`
        })
        .then(response => response.json())
        .then(data => {
            removeTypingIndicator();
            handleBotResponse(data);
        })
        .catch(error => {
            removeTypingIndicator();
            addMessage("Sorry, I'm having connection issues. Please try again.", 'bot');
            console.error('Error:', error);
        });
    }
    
    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add(`${sender}-message`);
        
        const messageContent = document.createElement('div');
        messageContent.classList.add('message-content');
        
        if (/<[a-z][\s\S]*>/i.test(text)) {
            messageContent.innerHTML = text;
        } else {
            const p = document.createElement('p');
            p.textContent = text;
            messageContent.appendChild(p);
        }
        
        const messageTime = document.createElement('div');
        messageTime.classList.add('message-time');
        messageTime.textContent = getCurrentTime();
        
        messageDiv.appendChild(messageContent);
        messageDiv.appendChild(messageTime);
        chatBox.appendChild(messageDiv);
        
        chatBox.scrollTop = chatBox.scrollHeight;
    }
    
    function handleBotResponse(response) {
        if (response.type === 'weather') {
            // Remove all weather classes first
            document.body.classList.remove(
                'sunny', 'cloudy', 'rainy', 'snowy', 'stormy', 'default'
            );
            
            // Add the new weather class
            if (response.weather_class) {
                document.body.classList.add(response.weather_class);
            }
        }
        addMessage(response.content, 'bot');
    }
    // function handleBotResponse(response) {
    //     if (response.type === 'weather') {
    //         // Remove all weather classes first
    //         document.body.className = '';
            
    //         // Add the base body class and weather class
    //         document.body.classList.add(response.weather_class);
            
    //         // Force redraw to trigger transition
    //         document.body.style.display = 'none';
    //         document.body.offsetHeight; // Trigger reflow
    //         document.body.style.display = '';
    //     }
    //     addMessage(response.content, 'bot');
    // }
    
    
    function showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.classList.add('typing-indicator');
        typingDiv.id = 'typing-indicator';
        
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('span');
            dot.classList.add('typing-dot');
            typingDiv.appendChild(dot);
        }
        
        chatBox.appendChild(typingDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
    
    function removeTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    function getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});