# from flask import Flask, render_template, request
# import requests
# from datetime import datetime

# app = Flask(__name__)

# # Replace with your OpenWeatherMap API key
# API_KEY = 'c7f8a54be442d2ce457076f410730800'
# BASE_URL = 'http://api.openweathermap.org/data/2.5/weather'
# FORECAST_URL = 'http://api.openweathermap.org/data/2.5/forecast'

# @app.route('/', methods=['GET', 'POST'])
# def index():
#     weather_data = None
#     forecast_data = None
#     error = None
#     current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#     if request.method == 'POST':
#         city = request.form['city']
#         weather_data, forecast_data, error = get_weather(city)
#     return render_template('index.html', weather_data=weather_data, forecast_data=forecast_data, error=error, current_time=current_time)

# @app.route('/graph')
# def graph():
#     city = request.args.get('city')
#     if city:
#         _, forecast_data, _ = get_weather(city)
#         return render_template('graph.html', forecast_data=forecast_data, city=city)
#     return render_template('graph.html', forecast_data=None, city=None)

# def get_weather(city):
#     try:
#         # Fetch current weather
#         params = {
#             'q': city,
#             'appid': API_KEY,
#             'units': 'metric'
#         }
#         response = requests.get(BASE_URL, params=params)
#         if response.status_code == 200:
#             data = response.json()
#             weather = {
#                 'city': data['name'],
#                 'temperature': data['main']['temp'],
#                 'description': data['weather'][0]['description'],
#                 'icon': data['weather'][0]['icon'],
#                 'humidity': data['main']['humidity'],
#                 'feels_like': data['main']['feels_like'],
#                 'wind_speed': data['wind']['speed'],
#                 'visibility': data.get('visibility', 'N/A'),
#                 'pressure': data['main']['pressure'],
#                 'dew_point': data['main']['temp_min']
#             }

#             # Fetch 24-hour forecast
#             forecast_response = requests.get(FORECAST_URL, params=params)
#             if forecast_response.status_code == 200:
#                 forecast = forecast_response.json()
#                 forecast_data = []
#                 for entry in forecast['list'][:8]:  # Next 24 hours (3-hour intervals)
#                     forecast_data.append({
#                         'time': entry['dt_txt'],
#                         'temperature': entry['main']['temp'],
#                         'description': entry['weather'][0]['description'],
#                         'icon': entry['weather'][0]['icon']
#                     })
#                 return weather, forecast_data, None
#             else:
#                 return weather, None, "Forecast data not available."
#         else:
#             return None, None, "City not found. Please try again."
#     except Exception as e:
#         return None, None, "An error occurred. Please try again later."

# if __name__ == '__main__':
#     app.run(debug=True)

# from flask import Flask, render_template, request
# import requests
# from datetime import datetime

# app = Flask(__name__)

# # Replace with your OpenWeatherMap API key
# API_KEY = 'c7f8a54be442d2ce457076f410730800'
# BASE_URL = 'http://api.openweathermap.org/data/2.5/weather'
# FORECAST_URL = 'http://api.openweathermap.org/data/2.5/forecast'

# @app.route('/', methods=['GET', 'POST'])
# def index():
#     weather_data = None
#     forecast_data = None
#     error = None
#     current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#     if request.method == 'POST':
#         city = request.form['city']
#         weather_data, forecast_data, error = get_weather(city)
#     return render_template('index.html', weather_data=weather_data, forecast_data=forecast_data, error=error, current_time=current_time)

# @app.route('/graph')
# def graph():
#     city = request.args.get('city')
#     if city:
#         _, forecast_data, _ = get_weather(city)
#         return render_template('graph.html', forecast_data=forecast_data, city=city)
#     return render_template('graph.html', forecast_data=None, city=None)

# def get_weather(city):
#     try:
#         # Fetch current weather
#         params = {
#             'q': city,
#             'appid': API_KEY,
#             'units': 'metric'
#         }
#         response = requests.get(BASE_URL, params=params)
#         if response.status_code == 200:
#             data = response.json()
#             weather = {
#                 'city': data['name'],
#                 'temperature': data['main']['temp'],
#                 'description': data['weather'][0]['description'],
#                 'icon': data['weather'][0]['icon'],
#                 'humidity': data['main']['humidity'],
#                 'feels_like': data['main']['feels_like'],
#                 'wind_speed': data['wind']['speed'],
#                 'visibility': data.get('visibility', 'N/A'),
#                 'pressure': data['main']['pressure'],
#                 'dew_point': data['main']['temp_min']
#             }

#             # Fetch 24-hour forecast
#             forecast_response = requests.get(FORECAST_URL, params=params)
#             if forecast_response.status_code == 200:
#                 forecast = forecast_response.json()
#                 forecast_data = []
#                 for entry in forecast['list'][:8]:  # Next 24 hours (3-hour intervals)
#                     forecast_data.append({
#                         'time': entry['dt_txt'],
#                         'temperature': entry['main']['temp'],
#                         'description': entry['weather'][0]['description'],
#                         'icon': entry['weather'][0]['icon']
#                     })
#                 return weather, forecast_data, None
#             else:
#                 return weather, None, "Forecast data not available."
#         else:
#             return None, None, "City not found. Please try again."
#     except Exception as e:
#         return None, None, "An error occurred. Please try again later."

# if __name__ == '__main__':
#     app.run(debug=True)


from flask import Flask, render_template, request
import requests
from datetime import datetime

app = Flask(__name__)

# Replace with your OpenWeatherMap API key
API_KEY = 'c7f8a54be442d2ce457076f410730800'
BASE_URL = 'http://api.openweathermap.org/data/2.5/weather'
FORECAST_URL = 'http://api.openweathermap.org/data/2.5/forecast'

@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None
    forecast_data = None
    error = None
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if request.method == 'POST':
        city = request.form['city']
        weather_data, forecast_data, error = get_weather(city)
    return render_template('index.html', weather_data=weather_data, forecast_data=forecast_data, error=error, current_time=current_time)

@app.route('/graph')
def graph():
    city = request.args.get('city')
    if city:
        _, forecast_data, _ = get_weather(city)
        return render_template('graph.html', forecast_data=forecast_data, city=city)
    return render_template('graph.html', forecast_data=None, city=None)

def get_weather(city):
    try:
        # Fetch current weather
        params = {
            'q': city,
            'appid': API_KEY,
            'units': 'metric'
        }
        response = requests.get(BASE_URL, params=params)
        if response.status_code == 200:
            data = response.json()
            weather = {
                'city': data['name'],
                'temperature': data['main']['temp'],
                'description': data['weather'][0]['description'],
                'icon': data['weather'][0]['icon'],
                'humidity': data['main']['humidity'],
                'feels_like': data['main']['feels_like'],
                'wind_speed': data['wind']['speed'],
                'visibility': data.get('visibility', 'N/A'),
                'pressure': data['main']['pressure'],
                'dew_point': data['main']['temp_min']
            }

            # Fetch 24-hour forecast
            forecast_response = requests.get(FORECAST_URL, params=params)
            if forecast_response.status_code == 200:
                forecast = forecast_response.json()
                forecast_data = []
                for entry in forecast['list'][:8]:  # Next 24 hours (3-hour intervals)
                    forecast_data.append({
                        'time': entry['dt_txt'],
                        'temperature': entry['main']['temp'],
                        'description': entry['weather'][0]['description'],
                        'icon': entry['weather'][0]['icon']
                    })
                return weather, forecast_data, None
            else:
                return weather, None, "Forecast data not available."
        else:
            return None, None, "City not found. Please try again."
    except Exception as e:
        return None, None, "An error occurred. Please try again later."

if __name__ == '__main__':
    app.run(debug=True)