from flask import Flask, render_template, request, jsonify
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import json

app = Flask(__name__)

def init_chatbot():
    # Load JSON data
    with open('intents.json', 'r') as f:
        intents = json.load(f)  # This should be a list of intent objects
    
    # Prepare questions and answers
    questions = []
    answers = []
    
    for intent in intents:  # Now directly iterating through the list
        for pattern in intent['patterns']:
            questions.append(pattern)
            answers.append(intent['responses'][0])  # Using first response
    
    # Generate embeddings
    model = SentenceTransformer('paraphrase-MiniLM-L6-v2')
    embeddings = model.encode(questions)
    
    # Build FAISS index
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)
    
    return model, index, questions, answers

model, index, questions, answers = init_chatbot()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    try:
        user_input = request.json['question']
        query_embedding = model.encode([user_input])
        distances, indices = index.search(query_embedding, k=1)
        
        return jsonify({
            "answer": answers[indices[0][0]],
            "status": "success"
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)